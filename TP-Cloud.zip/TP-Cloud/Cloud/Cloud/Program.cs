﻿  using System;
using System.Collections;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json.Linq;

class Program
{
    static readonly HttpClient client1 = new HttpClient();

    static async Task Main()
    {
        try
        {
            // Récupération des données depuis l'API
            HttpResponseMessage response = await client1.GetAsync("https://labonnealternance.apprentissage.beta.gouv.fr/api/v1/jobs?romes=K1903%2CM1101%2CM1604%2CM1805&caller=Ornelle&insee=75056&sources=offres"); 
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();

            // Transformation des données JSON en objet JObject
            JObject json = JObject.Parse(responseBody);

            // Accéder à la clé "results" dans le JSON
            JArray results = (JArray)json["peJobs"]["results"];
            
            // Connexion à la base de données MongoDB
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("testmongo");

            // Parcourir les éléments de "results" et les insérer dans MongoDB
            var collection = database.GetCollection<BsonDocument>("offer");

            foreach (JObject result in results)
            {
                var document = BsonDocument.Parse(result.ToString());

                await collection.InsertOneAsync(document);

            }

            var allOffers = await collection.Find(new BsonDocument()).ToListAsync();
            

            Console.WriteLine("Toutes les données ont été insérées avec succès dans MongoDB !");
            // Création de la table de hachage pour le routage
            var routingTable = new Hashtable();

            // Traitement des données pour la table de hachage
            ProcessDataForRouting(allOffers, routingTable);

            // Affichage de la table de hachage
            DisplayRoutingTable(routingTable);

            // Création des index MongoDB
            await CreateMongoDBIndexes(database);

        }
        catch (Exception e)
        {
            Console.WriteLine($"Une erreur s'est produite : {e.Message}");
        }
    }

    static void ProcessDataForRouting(List<BsonDocument> allOffers, Hashtable routingTable)
    {
        foreach (var offer in allOffers)
        {
            var jobType = offer.GetValue("job")?["contractType"];
          
            
                if (!routingTable.ContainsKey(jobType))
                {
                    routingTable[jobType] = new List<BsonValue>();
                }

                // Ajouter l'identifiant de l'offre à la liste correspondante dans la table de hachage
                var offerId = offer.GetValue("_id");
                ((List<BsonValue>)routingTable[jobType]).Add(offerId);
            
        }
    }
        static void DisplayRoutingTable(Hashtable routingTable)
        {
        Console.WriteLine("Table de hachage créée avec succès. Détails :");

        foreach (DictionaryEntry entry in routingTable)
        {
            BsonValue jobType = (BsonValue)entry.Key;
            List<BsonValue> offerIds = (List<BsonValue>)entry.Value;

            Console.WriteLine($"Key: {jobType}");

            foreach (var offerId in offerIds)
            {
                Console.WriteLine($"  {offerId}");
            }
        }
    }

    static async Task CreateMongoDBIndexes(IMongoDatabase database)
    {
        var offerCollection = database.GetCollection<BsonDocument>("offer");
        var keys = Builders<BsonDocument>.IndexKeys.Text("job.contractType");

        var options = new CreateIndexOptions
        {
            DefaultLanguage = "none" // Pour ignorer la division des mots
        };
        var model = new CreateIndexModel<BsonDocument>(keys, options);
        // Créer l'indice textuel sur le champ contractType
        offerCollection.Indexes.CreateOne(model);
    }


}




